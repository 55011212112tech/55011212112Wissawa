//
//  ViewController.swift
//  Exam1_55011212112
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func totalButton(sender: AnyObject)
    {
    
        var tvolume = volume.text
        var tprice = price.text
        
        var ivolume = tvolume.toInt()!
        var iprice = tprice.toInt()!
        
        var temp:Double = Double(iprice)
        
        var sum = ivolume * iprice
        total.text = String(sum)+" Bath"

        
    }

    @IBAction func bProfit(sender: AnyObject)
    {
        var profit1:Int
        var profit2:Int
        var profit3:Int
        
        profit1 = volume.text.toInt()! * (price.text.toInt()!)
        profit1 = (profit1 * 3)/100
        
        profit2 = volume.text.toInt()! * (price.text.toInt()!)
        profit2 = (profit2 * 5)/100
        
        profit3 = volume.text.toInt()! * (price.text.toInt()!)
        profit3 = (profit3 * 10)/100
            
        
        list1.text = "Price Up 3% : Profit \(profit1) Bath"
        list2.text = "Price Up 5% : Profit \(profit2) Bath"
        list3.text = "Price Up 10% : Profit \(profit3) Bath"
    }
    
    
    @IBOutlet var list1: UITextView!
    @IBOutlet var list2: UITextView!
    @IBOutlet var list3: UITextView!
    
    
    
    @IBOutlet var name: UITextField!
    
    @IBOutlet var volume: UITextField!
    @IBOutlet var price: UITextField!
    @IBOutlet var total: UITextField!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

